package routines;

import au.com.bytecode.opencsv.CSVWriter;

import java.io.File;
import java.io.FileWriter;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class Table{

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
    public static String helloExample(String TalendID) {
    	String strStatus="";
        try{
            DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=10.63.17.70)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=PPEFDEV.esotredevexaclt.coretrevcn01.oraclevcn.com)))","PEF_APP_USER","PEFApp1zero1");
            conn.setAutoCommit(false);
            Statement statement = conn.createStatement();
            ResultSet resultData = statement.executeQuery("select * from TABLE (tableau_table_fn_pkg.pv_gsp_forecast_tf('"+TalendID+"',50000))");

            CSVWriter writer = new CSVWriter(new FileWriter(new File("/u01/app/oracle/API/Output_1day.csv")), '|');
            writer.writeAll(resultData, true);
            // writer.flush();
            writer.close();
			strStatus = "file created successfully";

        }catch (Exception e){
            System.out.println("Error" +e);
			strStatus = "file creation failed";
        }
		return strStatus;

    }
}
