package routines;

import java.text.SimpleDateFormat; 

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class IEMSDateConversion {

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
	public static String dateConversion(String  strDate1, String  strTime1){
		String strDate = strDate1;
		String strTime = strTime1;
		String strHours = strTime.substring(0,2).contains("24")?"00":strTime.substring(0,2);
		
        SimpleDateFormat fromUser = new SimpleDateFormat("yyMMdd");
        SimpleDateFormat myFormat = new SimpleDateFormat("dd-MM-yyyy");
        String strOutTime = strHours+":"+strTime.substring(2,strTime.length())+":00";
        System.out.println("strTime ::: "+strOutTime);
        String outputDate="";
        try {

        outputDate = myFormat.format(fromUser.parse(strDate));
        } catch (Exception e) {
        e.printStackTrace();
        }
        return outputDate+" "+strOutTime;
    }
	public static String timeConversion(String  strTime1){
		String strTime = strTime1;
		String strHours = strTime.substring(0,2).contains("24")?"00":strTime.substring(0,2);
		String strOutTime = strHours+strTime.substring(2,strTime.length());
        System.out.println("strTime ::: "+strOutTime);
        return strOutTime;
    }

}
