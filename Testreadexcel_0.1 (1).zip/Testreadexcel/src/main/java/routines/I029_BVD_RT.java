package routines;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.*;
import java.text.*;
import java.util.*;

import oracle.sql.*;
import oracle.jdbc.*;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */

public class I029_BVD_RT {

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
    public static String I029BVD(String message, String strFileName, String strFileCreationTime,String DBConURL,String strUserID,String strPassword) throws Exception {
      	 String strStatus = "success";
      	 String FileName ="/u03/pef/pef-mod-io/bpd_process/output/"+strFileName;
          String connect_string = DBConURL.toString();
          String User_string = strUserID.toString();
          String Password_string = strPassword.toString();
          Connection conn = null;
          OracleCallableStatement callStmt = null;
          BufferedReader br = new BufferedReader(new FileReader(FileName));
          BufferedReader br1 = new BufferedReader(new FileReader(FileName));
          try {
	          Class.forName("oracle.jdbc.driver.OracleDriver");
	          conn = DriverManager.getConnection(connect_string,User_string,Password_string);
	          conn.setAutoCommit(false);
	          SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss");
	          java.util.Date lFromDate1 = datetimeFormatter1.parse(strFileCreationTime);
	          Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
	          callStmt = (OracleCallableStatement)conn.prepareCall("{call CDCA_I029.put_bp_data(?,?,?,?,?,?,?,?,?,?,?)}");
	          // descriptor for OBJECT type defined in database
	          StructDescriptor projectTypeDesc = StructDescriptor.createDescriptor("I029_BPD_OBJ", conn);
	          // 	descriptor of TABLE type defined in database
	          ArrayDescriptor projectTypeArrayDesc = ArrayDescriptor.createDescriptor("I029_BPD_TYPE", conn);
	          int i =0;
	          int rowCount =0;
	          String sCurrentLine;
	          int lines = 0;
	          while ((sCurrentLine =br.readLine()) != null) {
	        	  if(rowCount != 0){
	        		  if(sCurrentLine.trim().length() > 0){
	        			  lines++;
	        		  }
	        	  }
	        	  rowCount++;
	          }
//	          System.out.println("Total lines >>> "+lines);
              Object[][] project = new Object[lines][13];
              STRUCT[]structArrayOfProjects = new STRUCT[lines];
              int count =0;
              while (((sCurrentLine = br1.readLine()) != null) && (i < lines+1)) {
               	 if(count != 0){
                    String strCheck = sCurrentLine;
//                    System.out.println("inside while>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                    System.out.println("sCurrentLine>>>>"+sCurrentLine);
                     project[i] = new Object[13];
                     int k=0;
                     for (String mystring : strCheck.split("\\,", 0)) {
                                project[i][k++] = mystring;
                                System.out.print("myString >>>"+mystring);
                     }
                     STRUCT structProject1 = new STRUCT(projectTypeDesc, conn, project[i]);
                     structArrayOfProjects[i] = structProject1;
                     ++i;
                }
               	 count++;
              }
                System.out.println("talend id>>>>>>>>>>>>>>> "+project[0][0]);
                ARRAY arrayOfProjects = new ARRAY(projectTypeArrayDesc, conn, structArrayOfProjects);
                callStmt.setString(1,"I029");
                callStmt.setARRAY(2, arrayOfProjects); 
                callStmt.setString(3,strFileName); // filename
                callStmt.setTimestamp(4, fromTS1);
                callStmt.setString(5, "Talend");
                callStmt.registerOutParameter(6, java.sql.Types.VARCHAR);
                callStmt.registerOutParameter(7, java.sql.Types.VARCHAR);
                callStmt.registerOutParameter(8, java.sql.Types.NUMERIC);
                callStmt.registerOutParameter(9, java.sql.Types.VARCHAR);
                callStmt.registerOutParameter(10, java.sql.Types.NUMERIC);
                callStmt.registerOutParameter(11, java.sql.Types.VARCHAR);
                callStmt.execute();
                conn.commit();
                String status = callStmt.getString(7);
                          System.out.println("output >>>>"+status);
                          String Batch = callStmt.getString(11);
                          System.out.println("output >>>>"+Batch);
                if(status != null){
                	//          	System.out.println("am in failure case");
                	strStatus = status+"_"+Batch;
                }else{
                	//          	System.out.println("am in success case");
                }
                //          System.out.println("Committed.");
        } catch (Exception e) {
        	strStatus = "failure";
            e.printStackTrace();
            if (conn != null) try { conn.rollback(); } catch (Exception ex) { System.out.println("Rollback failed."); }
            //          throw e;
        } finally {
          callStmt.close();
          conn.close();
          br.close();
          br1.close();
         }
     System.out.println("Hello " + message + " !"); //$NON-NLS-1$ //$NON-NLS-2$
      return strStatus;
    }
}
