package routines;
import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.*;
import java.text.*;
import java.util.*;

import oracle.sql.*;
import oracle.jdbc.*;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class Weather_Actual_Routine {

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
	 public static String helloExample(String message, String FileName, int BPMCID, String FileCreationDate, String DBConnection, String DBuserid, String DBpassword, String ActualOutFile) throws Exception {
	    	String strstatus ="success";
	    	
	    	
//	      if (message == null) {
	   	 
	        //String connect_string = "jdbc:oracle:thin:DFSMOD/Sunrise6am@10.61.1.48:1521:NEWDFSMD";
	        Connection conn = null;
	        OracleCallableStatement callStmt = null;
	        try {
	        Class.forName("oracle.jdbc.driver.OracleDriver");
	        conn = DriverManager.getConnection(DBConnection,DBuserid,DBpassword);
//	      OracleConnection conn = getOracleConnection().unwrap(OracleConnection.class);
	     //System.out.println("Got Connection.");
	        conn.setAutoCommit(false);
	     SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
	                  "yyyy-MM-dd HH:mm:ss");
	     java.util.Date lFromDate1 = datetimeFormatter1.parse(FileCreationDate);

	  //System.out.println("gpsdate :" + lFromDate1);
	  Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
	        callStmt = (OracleCallableStatement)conn.prepareCall("{call Weather_Actual.Put_Raw_Data(?,?,?,?,?,?,?,?,?,?,?)}");
	        // descriptor for OBJECT type defined in database
	        StructDescriptor projectTypeDesc = StructDescriptor.createDescriptor("CDCAOBJECT_WEATHER_ACTUAL", conn);
	        // descriptor of TABLE type defined in database
	        ArrayDescriptor projectTypeArrayDesc = ArrayDescriptor.createDescriptor("WEATHERACTUALTYPE", conn);

	        int i =0;
	                BufferedReader br = new BufferedReader(new FileReader(ActualOutFile));
	              String sCurrentLine;
	              int lines = 0;
	              while (br.readLine() != null) lines++;
	              //System.out.println("Lines>>>>>>>>   "+lines);
	              Object[][] project = new Object[lines][18];
	              STRUCT[]structArrayOfProjects = new STRUCT[lines];
	              BufferedReader br1 = new BufferedReader(new FileReader(ActualOutFile));
	              while (((sCurrentLine = br1.readLine()) != null) && (i < lines)) {
	                  String strCheck = sCurrentLine;
	                  //System.out.println("inside while>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	                  //System.out.println("sCurrentLine>>>>"+sCurrentLine);
	                   project[i] = new Object[18];
	                   int k=0;
	                   for (String mystring : strCheck.split("\\,", 0)) {
	                              project[i][k++] = mystring;
	                    //          System.out.print("myString >>>"+mystring);
	                          }
	                  
//	                   project[i] = sCurrentLine;
	  STRUCT structProject1 = new STRUCT(projectTypeDesc, conn, project[i]);
	                   structArrayOfProjects[i] = structProject1;

	                   ++i;
	              }
	        ARRAY arrayOfProjects = new ARRAY(projectTypeArrayDesc, conn, structArrayOfProjects);
	        callStmt.setString(1,"WA");
	        callStmt.setString(2, String.valueOf(BPMCID)); // bpm id
	        callStmt.setARRAY(3, arrayOfProjects); 
	        callStmt.setString(4,FileName); // FileName
	        callStmt.setTimestamp(5, fromTS1);// file creation time
	        callStmt.setString(6, "Talend"); //user
	        callStmt.setString(7,project[0][0].toString()); //batchIdentifier
	        callStmt.registerOutParameter(8, java.sql.Types.NUMERIC);
	        callStmt.registerOutParameter(9, java.sql.Types.VARCHAR);
	        callStmt.registerOutParameter(10, java.sql.Types.NUMERIC);
	        callStmt.registerOutParameter(11, java.sql.Types.VARCHAR);
	       

	        callStmt.execute();
	        conn.commit();
	        String status = callStmt.getString(11);
	        //System.out.println("output >>>>"+status);
	        if(status != null){
	     //   	System.out.println("am in failure case");
	        	strstatus = status;
	        }else{
	     //   	System.out.println("am in success case");
	        } 

	        //System.out.println("Committed.");
	      } catch (Exception e) {
	    	  strstatus ="fail";
	          e.printStackTrace();
	        if (conn != null) try { conn.rollback(); } catch (Exception ex) { System.out.println("Rollback failed."); }
//	        throw e;
	      } finally {
	        callStmt.close();
	        conn.close();
	       }
//	    }
	    //System.out.println("Hello " + message + " !"); //$NON-NLS-1$ //$NON-NLS-2$
	    return strstatus;
	    }
}
