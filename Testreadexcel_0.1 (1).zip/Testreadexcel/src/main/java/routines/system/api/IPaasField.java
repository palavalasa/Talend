package routines.system.api;


public interface IPaasField {

    String getName();

    String getType();

    String getDefault();

    int getLength();

}
