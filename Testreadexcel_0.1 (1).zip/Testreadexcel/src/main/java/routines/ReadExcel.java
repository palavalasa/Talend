package routines;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

    private static final String FILE_PATH = "C:/Talend/Code/talend_routine/testReadStudents.xlsx";

    
    public static String getStudentsListFromExcel() {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(FILE_PATH);
            // Using XSSF for xlsx format, for xls use HSSF
            Workbook workbook = new XSSFWorkbook(fis);
            int numberOfSheets = workbook.getNumberOfSheets();
            //looping over each workbook sheet
            for (int i = 0; i < numberOfSheets; i++) {
                Sheet sheet = workbook.getSheetAt(i);
                String sheetName = workbook.getSheetName(i);
                System.out.println("sheetName>>>>>"+sheetName);
                BufferedWriter fileWriter =new BufferedWriter(new FileWriter("C:/Talend/Code/"+sheetName+".csv"));;
                Iterator<Row> rowIterator = sheet.iterator();
                String rowHeaderline = "";
                int lastcell=sheet.getRow(2).getLastCellNum();
                      //Non empty Last cell Number or index return
                    
                      for(int j=0;j<=lastcell;j++)
                      {
                          String rowHeaderColumnString = "";
                          try
                          {
                              rowHeaderColumnString = CellReference.convertNumToColString(j)+",";
                              rowHeaderline = rowHeaderline.concat(rowHeaderColumnString);
                              System.out.println(CellReference.convertNumToColString(j));
                          }catch(Exception e)
                          {
                              e.printStackTrace();
                              }
                      }
                rowHeaderline= rowHeaderline.substring(0,rowHeaderline.length()-1);
                fileWriter.newLine();
                fileWriter.write(rowHeaderline);
                //iterating over each row
                while (rowIterator.hasNext()) {
                    System.out.println("inside while");
                    Row row = rowIterator.next();
                    
                    Iterator<Cell> cellIterator = row.cellIterator();
                    int columnCount=0;
//                    System.out.println(row.toString());
                    //Iterating over each cell (column wise)  in a particular row.
                    System.out.println("columnCount   "+columnCount);
                    int counter =0;
                    String line = "";
                    while (cellIterator.hasNext()) {
                        String valueString = "";
                        Cell cell = cellIterator.next();
                            valueString = cell.toString()+",";
                        line = line.concat(valueString);
                    }
                    line= line.substring(0,line.length()-1);
                    fileWriter.newLine();
                    fileWriter.write(line); 
                }
                fileWriter.close();
            }
            fis.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
            }catch(Exception e){
                e.printStackTrace();
            }
      return "success";
    }
}
